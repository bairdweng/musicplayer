//
//  MusicSlider.h
//  Aufree
//
//  Created by Aufree on 11/7/15.
//  Copyright © 2015 The EST Group. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface MusicSlider : UISlider

@end
