//
//  MainMacos.h
//  pro
//
//  Created by xiaofan on 9/15/16.
//  Copyright © 2016 huaxia. All rights reserved.
//

#ifndef MainMacos_h
#define MainMacos_h
//
#define MAINSCREEN ([UIScreen mainScreen].bounds)

#define SCREEN_WIDTH ([UIScreen mainScreen].bounds.size.width)
#define SCREEN_HEIGHT ([UIScreen mainScreen].bounds.size.height)
static NSString *const isConnectted = @"isConnecttedKey";

#endif /* MainMacos_h */
