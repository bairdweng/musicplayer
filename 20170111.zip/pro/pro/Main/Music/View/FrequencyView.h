//
//  FrequencyView.h
//  pro
//
//  Created by Xiaowz on 16/10/10.
//  Copyright © 2016年 huaxia. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface FrequencyView : UIView
@property (nonatomic, assign, readonly) NSInteger number;
@property (nonatomic, assign) NSInteger volume;
@end
